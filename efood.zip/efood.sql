-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: 127.0.0.1:3308
-- Χρόνος δημιουργίας: 23 Ιαν 2024 στις 20:43:35
-- Έκδοση διακομιστή: 8.0.18
-- Έκδοση PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `efood`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `restaurant_has_product`
--

DROP TABLE IF EXISTS `restaurant_has_product`;
CREATE TABLE IF NOT EXISTS `restaurant_has_product` (
  `RestaurantID` int(45) NOT NULL AUTO_INCREMENT,
  `ProductID` int(45) NOT NULL,
  `Product_Quantity` int(45) NOT NULL,
  PRIMARY KEY (`RestaurantID`,`ProductID`)
) ENGINE=MyISAM AUTO_INCREMENT=6970 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Άδειασμα δεδομένων του πίνακα `restaurant_has_product`
--

INSERT INTO `restaurant_has_product` (`RestaurantID`, `ProductID`, `Product_Quantity`) VALUES
(2222, 1, 1000),
(4455, 1, 1500),
(3496, 2, 1400),
(6969, 1, 1700),
(5555, 3, 1200);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
